<script>
  // ⛳️ Put your real Fly URL here once the API is live.
  // Example: "https://tcba-api.fly.dev"
  window.API_BASE = "https://tcba-api.fly.dev";
</script>
