require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();

// ===== SETTINGS =====
const PORT = process.env.PORT || 5000;
const DB_PATH = path.join(__dirname, "db", "members.sqlite");

// ===== MIDDLEWARE =====
app.use(cors({ origin: "*", credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ===== DATABASE CONNECTION =====
let db = new sqlite3.Database(DB_PATH, (err) => {
    if (err) {
        console.error("❌ Database connection error:", err.message);
    } else {
        console.log("✅ Connected to SQLite database:", DB_PATH);
    }
});

// ===== ROOT ROUTE =====
app.get("/", (req, res) => {
    res.status(200).send("TCBA Backend is Running");
});

// ===== SIMPLE TEST ROUTE =====
app.get("/test", (req, res) => {
    res.status(200).send("OK");
});

// ===== LOGIN ROUTE =====
app.post("/login", (req, res) => {
    const { user, password } = req.body;

    if (!user || !password) {
        return res.status(400).json({ error: "Missing username/email or password" });
    }

    const sql = `
        SELECT id, username, email, password, status, isOfficer
        FROM members
        WHERE username = ? OR email = ?
        LIMIT 1
    `;

    db.get(sql, [user, user], (err, row) => {
        if (err) {
            console.error("❌ Login SQL error:", err.message);
            return res.status(500).json({ error: "Database error" });
        }

        if (!row) {
            return res.status(404).json({ error: "User not found" });
        }

        if (password !== row.password) {
            return res.status(401).json({ error: "Incorrect password" });
        }

        return res.json({
            success: true,
            id: row.id,
            status: row.status,
            isOfficer: row.isOfficer
        });
    });
});

// ===== START SERVER =====
app.listen(PORT, () => {
    console.log("====================================");
    console.log("🚀 TCBA Backend Server Started");
    console.log("📌 Listening on port:", PORT);
    console.log("📂 Database file:", DB_PATH);
    console.log("====================================");
});
